<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TestController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\user\HomeController;
use App\Http\Middleware\Auth;
use App\Http\Controllers\user\ProductController;




use Inertia\Inertia;


$base_url='user';



// Route::get('/student/home', [HomeController::class, 'welcomes']);


Route::get('/', function () {
    return Inertia::render('Home');
});


Route::get($base_url.'/test', [TestController::class, 'hello']);



Route::post($base_url.'/submit', [TestController::class, 'submitForm']);


Route::get($base_url.'/login', [LoginController::class, 'login']);




Route::get($base_url.'/signup', [LoginController::class, 'signup'])->name('signup');



Route::get('/login', [LoginController::class, 'login'])->name('login');

Route::post('/register', [LoginController::class, 'register'])->name('register');


Route::post('/login_form', [LoginController::class, 'submit'])->name('login_form');

Route::get('/logout', [LoginController::class, 'logout'])->name('logout');





Route::get('/index', [LoginController::class, 'landing_page'])->name('landing');










Route::get('/admin/login', [LoginController::class, 'admin_login']);





// Route::get('/student/home_s', [HomeController::class, 'welcomes'])->name('home');


// Route::middleware([Auth::class])->group(function () {
//    
//    
//    



//  });



 Route::middleware(['auth'])->group(function () {
    // Route::get('/home', [HomeController::class, 'home'])->name('home');
    Route::get('/user/home', [HomeController::class, 'home'])->name('home');

    Route::get('/user/profile', [HomeController::class, 'profile'])->name('profile');
    Route::get('/user/home1', [HomeController::class, 'home'])->name('homea');


    Route::get('/user/add-product', [ProductController::class, 'add_product'])->name('add-product');


    Route::post('/profile/update', [HomeController::class, 'updateProfile'])->name('profile.update');


    Route::post('/product/store', [ProductController::class, 'store'])->name('product.store');


    Route::get('user/product/details/{id}', [ProductController::class, 'details'])->name('product.show');


});
